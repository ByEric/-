package com.jxx.mypc.myapplication.trackcalendar;

/**
 * Created by MY PC on 2016/11/3.
 */
public class NumberHelper {

    public static String LeftPad_Tow_Zero(int str) {
        java.text.DecimalFormat format = new java.text.DecimalFormat("00");
        return format.format(str);

    }

}
